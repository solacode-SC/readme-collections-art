import { describe, it, expect } from "vitest";
import { escapeXml } from "../src/lib/svg";
import { swirlStyle } from "../src/styles/swirl";
import { DEFAULT_CONTENT } from "../src/lib/defaultContent";
import { validateContent } from "../src/lib/validate";

describe("XML Escaping & Security", () => {
  it("escapes all special characters including & < > \" '", () => {
    const input = `AT&T <script>alert("xss")</script> 'hello'`;
    const escaped = escapeXml(input);
    expect(escaped).toBe("AT&amp;T &lt;script&gt;alert(&quot;xss&quot;)&lt;/script&gt; &apos;hello&apos;");
    expect(escaped).not.toContain("<script>");
  });

  it("handles null or undefined safely", () => {
    expect(escapeXml(null)).toBe("");
    expect(escapeXml(undefined)).toBe("");
  });
});

describe("Content Validation", () => {
  it("validates github handle format correctly", () => {
    const valid = validateContent(DEFAULT_CONTENT);
    expect(valid.filter((v) => v.type === "error")).toHaveLength(0);

    const invalid = validateContent({
      ...DEFAULT_CONTENT,
      handle: "Invalid Handle With Spaces!",
    });
    expect(invalid.some((v) => v.field === "handle" && v.type === "error")).toBe(true);
  });

  it("warns about placeholder LinkedIn URL", () => {
    const issues = validateContent(DEFAULT_CONTENT);
    const linkedInIssue = issues.find((v) => v.field === "linkedin");
    expect(linkedInIssue).toBeDefined();
    expect(linkedInIssue?.type).toBe("warning");
  });
});

describe("Swirl Procedural Engine", () => {
  it("renders with default content without throwing", () => {
    const mockCtx = {
      loadImage: async () => ({}) as any,
      cropToDataUrl: () => "data:image/jpeg;base64,mock",
    };
    const res = swirlStyle.render(DEFAULT_CONTENT, mockCtx);
    expect(res).toBeDefined();
    if ("then" in res) {
      // Async handling
    } else {
      expect(res.readme).toContain("solacode-SC");
      expect(res.readme).toContain("<picture>");
      expect(res.files["hero-dark.svg"]).toBeDefined();
      expect(res.files["hero-light.svg"]).toBeDefined();
      expect(res.meta.bytes).toBeGreaterThan(1000);
    }
  });

  it("safely handles XSS attempts in name and project titles", () => {
    const attackContent = {
      ...DEFAULT_CONTENT,
      name: "Solayman & <Co>",
      projects: [
        {
          title: "Attack & Test <script>",
          slug: "attack-test",
          line1: "line 1 & 2",
          line2: "line 2 <tag>",
          tags: ["XSS & 1", "<tag>"],
        },
      ],
    };
    const mockCtx = {
      loadImage: async () => ({}) as any,
      cropToDataUrl: () => "data:image/jpeg;base64,mock",
    };
    const res = swirlStyle.render(attackContent, mockCtx);
    if (!("then" in res)) {
      expect(res.files["hero-dark.svg"]).not.toContain("<Co>");
      expect(res.files["hero-dark.svg"]).toContain("&lt;Co&gt;");
      expect(res.files["card-attack-test-dark.svg"]).not.toContain("<script>");
      expect(res.files["card-attack-test-dark.svg"]).toContain("&lt;script&gt;");
    }
  });
});
