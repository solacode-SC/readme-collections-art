import React from "react";
import { StyleModule } from "../types";

interface StyleGalleryProps {
  styles: StyleModule[];
  selectedId: string;
  onSelect: (id: string) => void;
  activeKeyword: string | null;
  onKeywordClick: (kw: string | null) => void;
}

export const StyleGallery: React.FC<StyleGalleryProps> = ({
  styles,
  selectedId,
  onSelect,
  activeKeyword,
}) => {
  const filtered = activeKeyword
    ? styles.filter((s) => s.keywords.includes(activeKeyword))
    : styles;

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span className="micro-label">STYLES ({filtered.length})</span>
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        {filtered.map((s) => {
          const isSelected = s.id === selectedId;
          return (
            <div
              key={s.id}
              onClick={() => onSelect(s.id)}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "8px",
                padding: "12px",
                borderRadius: "10px",
                border: isSelected ? "1px solid var(--ink-900)" : "1px solid var(--stone-300)",
                backgroundColor: isSelected ? "var(--ink-900)" : "transparent",
                color: isSelected ? "var(--paper-100)" : "var(--ink-900)",
                cursor: "pointer",
                transition: "all 0.18s ease-out",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                <span style={{ fontWeight: 600, fontSize: "14px" }}>{s.name}</span>
                <span
                  style={{
                    fontSize: "10px",
                    fontFamily: "var(--font-mono)",
                    opacity: 0.7,
                  }}
                >
                  {s.motion}
                </span>
              </div>

              {/* Keywords */}
              <div style={{ display: "flex", flexWrap: "wrap", gap: "4px" }}>
                {s.keywords.map((kw) => (
                  <span
                    key={kw}
                    style={{
                      fontSize: "9.5px",
                      padding: "2px 6px",
                      borderRadius: "999px",
                      border: isSelected
                        ? "1px solid rgba(255,255,255,0.25)"
                        : "1px solid var(--stone-300)",
                      color: isSelected ? "var(--paper-100)" : "var(--ink-500)",
                    }}
                  >
                    {kw}
                  </span>
                ))}
              </div>

              {/* Palette dots */}
              <div style={{ display: "flex", gap: "6px", alignItems: "center", marginTop: "2px" }}>
                {s.palette.dark.slice(0, 5).map((hex, idx) => (
                  <div
                    key={idx}
                    style={{
                      width: "12px",
                      height: "12px",
                      borderRadius: "50%",
                      backgroundColor: hex,
                      border: "1px solid rgba(0,0,0,0.15)",
                    }}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
