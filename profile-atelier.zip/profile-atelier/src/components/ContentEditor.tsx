import React from "react";
import { Content, Project } from "../types";

interface ContentEditorProps {
  content: Content;
  onChange: (updated: Content) => void;
  onReset: () => void;
}

export const ContentEditor: React.FC<ContentEditorProps> = ({ content, onChange, onReset }) => {
  const update = (partial: Partial<Content>) => {
    onChange({ ...content, ...partial });
  };

  const updateProject = (index: number, partial: Partial<Project>) => {
    const list = [...content.projects];
    list[index] = { ...list[index], ...partial };
    update({ projects: list });
  };

  const addProject = () => {
    const newProj: Project = {
      title: "New Project",
      slug: "new-project",
      line1: "Project description line 1",
      line2: "Project description line 2",
      tags: ["React", "TypeScript"],
    };
    update({ projects: [...content.projects, newProj] });
  };

  const removeProject = (index: number) => {
    update({ projects: content.projects.filter((_, i) => i !== index) });
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "20px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <span className="micro-label">CONTENT SPEC</span>
        <button
          onClick={onReset}
          style={{
            background: "none",
            border: "none",
            fontSize: "10.5px",
            color: "var(--ink-500)",
            cursor: "pointer",
            textDecoration: "underline",
          }}
        >
          Reset to defaults
        </button>
      </div>

      {/* Identity block */}
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <span className="micro-label">IDENTITY</span>
        <div>
          <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>Name (max 28)</label>
          <input
            className="input-field"
            maxLength={28}
            value={content.name}
            onChange={(e) => update({ name: e.target.value })}
          />
        </div>
        <div>
          <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>Role (max 28)</label>
          <input
            className="input-field"
            maxLength={28}
            value={content.role}
            onChange={(e) => update({ role: e.target.value })}
          />
        </div>
        <div>
          <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>Pillars</label>
          <input
            className="input-field"
            value={content.pillars}
            onChange={(e) => update({ pillars: e.target.value })}
          />
        </div>
      </div>

      <hr className="hairline-h" />

      {/* Links block */}
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <span className="micro-label">LINKS</span>
        <div>
          <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>GitHub URL</label>
          <input
            className="input-field"
            value={content.github}
            onChange={(e) => update({ github: e.target.value })}
          />
        </div>
        <div>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>LinkedIn URL</label>
            {content.linkedin.includes("YOUR-LINKEDIN") && (
              <span style={{ fontSize: "10px", color: "#b91c1c", fontWeight: 600 }}>
                Placeholder!
              </span>
            )}
          </div>
          <input
            className="input-field"
            value={content.linkedin}
            onChange={(e) => update({ linkedin: e.target.value })}
          />
        </div>
        <div>
          <label style={{ fontSize: "11px", color: "var(--ink-500)" }}>Portfolio URL</label>
          <input
            className="input-field"
            value={content.portfolio}
            onChange={(e) => update({ portfolio: e.target.value })}
          />
        </div>
      </div>

      <hr className="hairline-h" />

      {/* About text */}
      <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
        <span className="micro-label">ABOUT PARAGRAPHS</span>
        {content.about.map((p, idx) => (
          <textarea
            key={idx}
            className="input-field"
            rows={3}
            value={p}
            onChange={(e) => {
              const list = [...content.about];
              list[idx] = e.target.value;
              update({ about: list });
            }}
          />
        ))}
      </div>

      <hr className="hairline-h" />

      {/* Projects */}
      <div style={{ display: "flex", flexDirection: "column", gap: "12px" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span className="micro-label">PROJECTS ({content.projects.length})</span>
          <button
            onClick={addProject}
            className="pill"
            style={{ height: "22px", fontSize: "10px", padding: "0 8px" }}
          >
            + Add Project
          </button>
        </div>

        {content.projects.map((proj, idx) => (
          <div
            key={idx}
            style={{
              display: "flex",
              flexDirection: "column",
              gap: "6px",
              padding: "10px",
              borderRadius: "8px",
              border: "1px solid var(--stone-300)",
              backgroundColor: "var(--paper-100)",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontSize: "11px", fontWeight: 600 }}>#{idx + 1} {proj.title}</span>
              <button
                onClick={() => removeProject(idx)}
                style={{
                  background: "none",
                  border: "none",
                  color: "#b91c1c",
                  fontSize: "11px",
                  cursor: "pointer",
                }}
              >
                ✕
              </button>
            </div>
            <input
              className="input-field"
              placeholder="Title"
              maxLength={18}
              value={proj.title}
              onChange={(e) => {
                const title = e.target.value;
                const slug = title.toLowerCase().replace(/[^a-z0-9]+/g, "-");
                updateProject(idx, { title, slug });
              }}
            />
            <input
              className="input-field"
              placeholder="Line 1 (max 30)"
              maxLength={30}
              value={proj.line1}
              onChange={(e) => updateProject(idx, { line1: e.target.value })}
            />
            <input
              className="input-field"
              placeholder="Line 2 (max 30)"
              maxLength={30}
              value={proj.line2}
              onChange={(e) => updateProject(idx, { line2: e.target.value })}
            />
          </div>
        ))}
      </div>
    </div>
  );
};
