import React, { useMemo } from "react";
import { Content, RenderResult } from "../types";
import { ThemeMode, MotionMode, DeviceMode } from "../state/store";
import { GithubFrame } from "./GithubFrame";
import { PhoneFrame } from "./PhoneFrame";

interface PreviewStageProps {
  content: Content;
  theme: ThemeMode;
  motion: MotionMode;
  device: DeviceMode;
  result: RenderResult | null;
  onLinkedInWarning?: () => void;
}

export const PreviewStage: React.FC<PreviewStageProps> = ({
  content,
  theme,
  motion,
  device,
  result,
}) => {
  // Create Blob URLs with motion handling
  const blobUrls = useMemo(() => {
    if (!result) return {};
    const map: Record<string, string> = {};

    for (const [name, svgText] of Object.entries(result.files)) {
      let finalSvg = svgText;
      if (motion === "reduced") {
        finalSvg = finalSvg.replace(
          "</style>",
          `* { animation: none !important; transition: none !important; }\n</style>`
        );
      }
      const blob = new Blob([finalSvg], { type: "image/svg+xml" });
      map[name] = URL.createObjectURL(blob);
    }
    return map;
  }, [result, motion]);

  if (!result) {
    return (
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          height: "400px",
          color: "var(--ink-500)",
        }}
      >
        Rendering preview...
      </div>
    );
  }

  const getUrl = (prefix: string) => blobUrls[`${prefix}-${theme}.svg`];

  const contentElements = (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "16px", width: "100%" }}>
      {/* Hero */}
      {getUrl("hero") && (
        <img
          src={getUrl("hero")}
          alt={`${content.name} hero`}
          style={{ width: "100%", height: "auto", display: "block" }}
        />
      )}

      {/* Buttons */}
      <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", justifyContent: "center" }}>
        {getUrl("btn-github") && (
          <a href={content.github} target="_blank" rel="noreferrer">
            <img src={getUrl("btn-github")} alt="GitHub" style={{ height: "40px" }} />
          </a>
        )}
        {getUrl("btn-linkedin") && (
          <a
            href={content.linkedin}
            target="_blank"
            rel="noreferrer"
            onClick={(e) => {
              if (content.linkedin.includes("YOUR-LINKEDIN")) {
                e.preventDefault();
                alert("Please update your LinkedIn URL in the Content editor!");
              }
            }}
          >
            <img src={getUrl("btn-linkedin")} alt="LinkedIn" style={{ height: "40px" }} />
          </a>
        )}
        {getUrl("btn-portfolio") && (
          <a href={content.portfolio} target="_blank" rel="noreferrer">
            <img src={getUrl("btn-portfolio")} alt="Portfolio" style={{ height: "40px" }} />
          </a>
        )}
      </div>

      {/* About */}
      {getUrl("about") && (
        <img
          src={getUrl("about")}
          alt="About"
          style={{ width: "100%", height: "auto", display: "block" }}
        />
      )}

      {/* Skills */}
      {getUrl("skills") && (
        <img
          src={getUrl("skills")}
          alt="Skills"
          style={{ width: "100%", height: "auto", display: "block" }}
        />
      )}

      {/* Projects Title */}
      {getUrl("projects-title") && (
        <img
          src={getUrl("projects-title")}
          alt="Selected Projects"
          style={{ width: "100%", height: "auto", display: "block" }}
        />
      )}

      {/* Projects Cards Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: device === "phone" ? "repeat(2, 1fr)" : "repeat(4, 1fr)",
          gap: "10px",
          width: "100%",
        }}
      >
        {content.projects.map((proj) => {
          const cardUrl = getUrl(`card-${proj.slug}`);
          if (!cardUrl) return null;
          return (
            <a
              key={proj.slug}
              href={`${content.github}/${proj.slug}`}
              target="_blank"
              rel="noreferrer"
              style={{ display: "block" }}
            >
              <img
                src={cardUrl}
                alt={proj.title}
                style={{ width: "100%", height: "auto", display: "block" }}
              />
            </a>
          );
        })}
      </div>

      {/* Footer */}
      {getUrl("footer") && (
        <img
          src={getUrl("footer")}
          alt="Footer"
          style={{ width: "100%", height: "auto", display: "block" }}
        />
      )}

      <div style={{ fontSize: "11px", color: "var(--ink-500)", marginTop: "8px" }}>
        <a href={content.portfolio} target="_blank" rel="noreferrer" style={{ color: "inherit" }}>
          {content.portfolio.replace(/^https?:\/\//, "")}
        </a>{" "}
        ·{" "}
        <a href={content.linkedin} target="_blank" rel="noreferrer" style={{ color: "inherit" }}>
          LinkedIn
        </a>
      </div>
    </div>
  );

  return (
    <div style={{ width: "100%" }}>
      {device === "phone" ? (
        <PhoneFrame theme={theme}>{contentElements}</PhoneFrame>
      ) : (
        <GithubFrame handle={content.handle} theme={theme}>
          {contentElements}
        </GithubFrame>
      )}
    </div>
  );
};
