import { StyleModule } from "../types";
import { swirlStyle } from "./swirl";
import { moongateStyle } from "./moongate";
import { gardenStyle } from "./garden";
import { phoenixStyle } from "./phoenix";
import { andalusStyle } from "./andalus";
import { codexStyle } from "./codex";
import { inkscrollStyle } from "./inkscroll";

export const STYLES: StyleModule[] = [
  swirlStyle,
  moongateStyle,
  gardenStyle,
  phoenixStyle,
  andalusStyle,
  codexStyle,
  inkscrollStyle,
];

export function getStyleById(id: string): StyleModule {
  return STYLES.find((s) => s.id === id) || STYLES[0];
}
