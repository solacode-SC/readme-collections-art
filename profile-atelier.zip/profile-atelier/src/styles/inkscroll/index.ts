import { Content, RenderCtx, RenderResult, StyleModule } from "../../types";
import { escapeXml, f1, pic } from "../../lib/svg";

const SERIF = "Georgia,'Iowan Old Style','Palatino Linotype','Book Antiqua','DejaVu Serif',serif";
const MONO = "'JetBrains Mono','SF Mono',SFMono-Regular,Consolas,Menlo,monospace";
const CJK = "'KaiTi','STKaiti','Kaiti SC','AR PL UKai CN','Noto Serif SC','Songti SC','SimSun',serif";

interface ThemeColors {
  bg1: string;
  bg2: string;
  fg: string;
  ink: string;
  mute: string;
  indigo: string;
  verm: string;
  line: string;
  card: string;
  mount: string;
  mount2: string;
  green: string;
  paper: string;
  petal: string[];
}

const THEMES: Record<"dark" | "light", ThemeColors> = {
  light: {
    bg1: "#f3e9cd",
    bg2: "#e4d4a9",
    fg: "#26211b",
    ink: "#23201c",
    mute: "#6a5f4d",
    indigo: "#29486f",
    verm: "#bf2a22",
    line: "#b9a77a",
    card: "#f8f0d6",
    mount: "#b3c3ca",
    mount2: "#8ea5b2",
    green: "#3a6b4a",
    paper: "#f6edd2",
    petal: ["#f4d6d0", "#e9a8a0", "#bf2a22"],
  },
  dark: {
    bg1: "#181d28",
    bg2: "#0d1017",
    fg: "#efe5cb",
    ink: "#d9cfb6",
    mute: "#a99f88",
    indigo: "#93b3d9",
    verm: "#d6402f",
    line: "#3b4662",
    card: "#1b2130",
    mount: "#2a3c55",
    mount2: "#42597a",
    green: "#6aa77e",
    paper: "#efe5cb",
    petal: ["#efe3cf", "#d99a96", "#d6402f"],
  },
};

const STYLE = `<style>
.sway{transform-origin:710px 8px;animation:sway 11s ease-in-out infinite alternate}
@keyframes sway{from{transform:rotate(-.45deg)}to{transform:rotate(.45deg)}}
.drift{animation:drift 60s ease-in-out infinite alternate}
@keyframes drift{from{transform:translateX(-26px)}to{transform:translateX(26px)}}
.pfall{animation:pfall linear infinite}
@keyframes pfall{from{transform:translateY(-30px)}to{transform:translateY(560px)}}
.psway{transform-box:fill-box;transform-origin:center;animation:psway ease-in-out infinite alternate}
@keyframes psway{from{transform:translateX(-26px) rotate(-30deg)}to{transform:translateX(26px) rotate(30deg)}}
@media (prefers-reduced-motion:reduce){.sway,.drift,.pfall,.psway{animation:none}}
</style>`;

function defs(c: ThemeColors): string {
  return `<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c.bg1}"/><stop offset="1" stop-color="${c.bg2}"/></linearGradient>
</defs>`;
}

function wrap(w: number, h: number, c: ThemeColors, body: string, edge = true): string {
  const side = edge ? `<path d="M.5 0V${h}M${w - 0.5} 0V${h}" stroke="${c.line}"/>` : "";
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" font-family="${SERIF}">
${STYLE}${defs(c)}<rect width="${w}" height="${h}" fill="url(#bg)"/>${body}${side}</svg>`;
}

function seal(x: number, y: number, text: string, c: ThemeColors): string {
  return `<rect x="${x}" y="${y}" width="28" height="28" rx="2" fill="${c.verm}" stroke="${c.ink}" stroke-width=".8"/>
<text x="${x + 14}" y="${y + 20}" font-size="14" font-family="${CJK}" text-anchor="middle" fill="#fff">${escapeXml(text)}</text>`;
}

function hero(c: ThemeColors, content: Content, heroImg: string): string {
  let b = `<image x="470" y="24" width="380" height="370" preserveAspectRatio="xMidYMid slice" href="${heroImg}" xlink:href="${heroImg}" class="drift"/>`;
  b += `<rect x="470" y="24" width="380" height="370" fill="none" stroke="${c.line}" stroke-width="1.5"/>`;

  // Seal mark
  b += seal(50, 40, content.options.useCJK ? "印" : "SC", c);

  b += `<text x="90" y="60" font-size="13" font-family="${MONO}" letter-spacing="2" fill="${c.mute}">${escapeXml(content.handle.toUpperCase())}</text>
<text x="50" y="140" font-size="44" font-weight="700" fill="${c.ink}">${escapeXml(content.name)}</text>
<text x="52" y="180" font-size="15" font-family="${MONO}" letter-spacing="2" fill="${c.verm}">${escapeXml(content.role.toUpperCase())}</text>
<text x="52" y="220" font-size="13" letter-spacing="1" fill="${c.mute}" xml:space="preserve">${escapeXml(content.pillars)}</text>`;

  content.tagline.forEach((t, i) => {
    b += `<text x="52" y="${260 + i * 22}" font-size="12.5" fill="${c.fg}">${escapeXml(t)}</text>`;
  });

  if (content.options.useCJK) {
    const chars = "流水不腐戶樞不蠹";
    Array.from(chars).forEach((ch, i) => {
      b += `<text x="868" y="${60 + i * 24}" font-size="13" font-family="${CJK}" text-anchor="middle" fill="${c.mute}" opacity=".6">${escapeXml(ch)}</text>`;
    });
  }

  return wrap(900, 420, c, b);
}

function button(c: ThemeColors, label: string): string {
  const w = 150;
  const b = `<rect x="1" y="1" width="${w - 2}" height="38" rx="3" fill="${c.card}" stroke="${c.line}" stroke-width="1"/>
${seal(12, 10, "墨", c)}
<text x="50" y="25" font-size="12" font-family="${MONO}" font-weight="700" fill="${c.fg}">${escapeXml(label.toUpperCase())}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} 40" width="${w}" height="40">${b}</svg>`;
}

function about(c: ThemeColors, content: Content): string {
  let b = seal(50, 30, content.options.useCJK ? "卷" : "01", c);
  b += `<text x="90" y="50" font-size="18" font-weight="700" fill="${c.ink}">ABOUT</text>`;

  const lines: string[] = [];
  content.about.forEach((p, idx) => {
    if (idx > 0) lines.push("");
    const words = p.split(" ");
    let cur = "";
    words.forEach((w) => {
      if ((cur + " " + w).trim().length > 44) {
        lines.push(cur.trim());
        cur = w;
      } else {
        cur = (cur + " " + w).trim();
      }
    });
    if (cur) lines.push(cur);
  });

  lines.slice(0, 8).forEach((t, i) => {
    b += `<text x="50" y="${95 + i * 21}" font-size="13" fill="${c.fg}" xml:space="preserve">${escapeXml(t)}</text>`;
  });

  b += `<line x1="460" y1="35" x2="460" y2="245" stroke="${c.line}" stroke-dasharray="3 3"/>`;
  b += seal(490, 30, content.options.useCJK ? "行" : "02", c);
  b += `<text x="530" y="50" font-size="18" font-weight="700" fill="${c.ink}">JOURNEY</text>`;

  content.journey.slice(0, 5).forEach((j, i) => {
    const y = 95 + i * 30;
    b += `<text x="495" y="${y}" font-size="13" font-family="${MONO}" fill="${c.fg}">${escapeXml(j.lang)}</text>
<text x="630" y="${y}" font-size="13" fill="${c.verm}">—</text>
<text x="660" y="${y}" font-size="13" fill="${c.mute}">${escapeXml(j.area)}</text>`;
  });

  return wrap(900, 280, c, b);
}

function skills(c: ThemeColors, content: Content): string {
  let b = seal(50, 24, content.options.useCJK ? "術" : "03", c);
  b += `<text x="90" y="44" font-size="18" font-weight="700" fill="${c.ink}">SKILLS &amp; TECHNOLOGIES</text>`;

  const w = 125, g = 14;
  content.skills.slice(0, 12).forEach((s, i) => {
    const x = 40 + (i % 6) * (w + g);
    const y = 68 + Math.floor(i / 6) * 65;
    b += `<rect x="${x}" y="${y}" width="${w}" height="52" rx="3" fill="${c.card}" stroke="${c.line}" stroke-width="1"/>
<text x="${x + w / 2}" y="${y + 24}" font-size="15" font-family="${MONO}" font-weight="700" text-anchor="middle" fill="${c.verm}">${escapeXml(s.mono)}</text>
<text x="${x + w / 2}" y="${y + 42}" font-size="11" text-anchor="middle" fill="${c.fg}">${escapeXml(s.label)}</text>`;
  });

  return wrap(900, 230, c, b);
}

function projectsTitle(c: ThemeColors): string {
  let b = seal(50, 16, "品", c);
  b += `<text x="90" y="36" font-size="18" font-weight="700" fill="${c.ink}">SELECTED PROJECTS</text>`;
  return wrap(900, 60, c, b);
}

function card(
  c: ThemeColors,
  title: string,
  d1: string,
  d2: string,
  tags: string[],
  cardImg: string
): string {
  const w = 208, h = 184;
  let b = `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="4" fill="${c.card}" stroke="${c.line}" stroke-width="1"/>
<image x="8" y="8" width="192" height="68" preserveAspectRatio="xMidYMid slice" href="${cardImg}" xlink:href="${cardImg}"/>
<rect x="8" y="8" width="192" height="68" fill="none" stroke="${c.line}" stroke-width="1"/>
<text x="14" y="98" font-size="13" font-weight="700" fill="${c.fg}">${escapeXml(title)}</text>
<text x="14" y="116" font-size="10" fill="${c.mute}">${escapeXml(d1)}</text>
<text x="14" y="129" font-size="10" fill="${c.mute}">${escapeXml(d2)}</text>`;

  let x = 14;
  tags.slice(0, 4).forEach((t) => {
    const cw = t.length * 5.1 + 8;
    b += `<rect x="${f1(x)}" y="148" width="${f1(cw)}" height="16" rx="2" fill="none" stroke="${c.line}"/>
<text x="${f1(x + cw / 2)}" y="159" font-size="8" font-family="${MONO}" text-anchor="middle" fill="${c.verm}">${escapeXml(t)}</text>`;
    x += cw + 4;
  });

  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${b}</svg>`;
}

function footer(c: ThemeColors, content: Content): string {
  let b = `<text x="450" y="45" font-size="16" font-weight="700" letter-spacing="3" text-anchor="middle" fill="${c.ink}">${escapeXml(content.footer.line1.toUpperCase())}</text>
<text x="450" y="70" font-size="11" letter-spacing="1" text-anchor="middle" fill="${c.mute}">${escapeXml(content.footer.line2)}</text>
<g transform="translate(436 82)">${seal(0, 0, "志", c)}</g>`;
  return wrap(900, 130, c, b);
}

export const inkscrollStyle: StyleModule = {
  id: "inkscroll",
  name: "Ink Scroll",
  keywords: ["Chinese scroll", "hand-painted", "calm"],
  palette: {
    light: ["#f3e9cd", "#26211b", "#bf2a22", "#29486f", "#b3c3ca"],
    dark: ["#181d28", "#efe5cb", "#d6402f", "#93b3d9", "#2a3c55"],
  },
  motion: "calm",
  image: { file: "source.jpg", note: "Hand-painted hanging scroll" },
  options: ["useCJK"],
  async render(content: Content, ctx: RenderCtx): Promise<RenderResult> {
    const img = await ctx.loadImage("/art/inkscroll/source.jpg");
    const heroCrop = ctx.cropToDataUrl(img, [100, 140, 730, 800], [500, 420], 0.82);

    const cropBoxes: [number, number, number, number][] = [
      [270, 385, 470, 479],
      [120, 865, 320, 957],
      [140, 440, 340, 532],
      [270, 790, 470, 882],
      [100, 140, 300, 232],
      [250, 270, 450, 362],
      [536, 370, 736, 462],
    ];

    const cardCrops = content.projects.map((_, i) =>
      ctx.cropToDataUrl(img, cropBoxes[i % cropBoxes.length], [384, 136], 0.8)
    );

    const files: Record<string, string> = {};
    for (const theme of ["dark", "light"] as const) {
      const c = THEMES[theme];
      files[`hero-${theme}.svg`] = hero(c, content, heroCrop);
      files[`about-${theme}.svg`] = about(c, content);
      files[`skills-${theme}.svg`] = skills(c, content);
      files[`projects-title-${theme}.svg`] = projectsTitle(c);
      files[`footer-${theme}.svg`] = footer(c, content);
      files[`btn-github-${theme}.svg`] = button(c, "GitHub");
      files[`btn-linkedin-${theme}.svg`] = button(c, "LinkedIn");
      files[`btn-portfolio-${theme}.svg`] = button(c, "Portfolio");

      content.projects.forEach((proj, idx) => {
        files[`card-${proj.slug}-${theme}.svg`] = card(
          c,
          proj.title,
          proj.line1,
          proj.line2,
          proj.tags,
          cardCrops[idx]
        );
      });
    }

    const cardPics = (items: typeof content.projects) =>
      items
        .map(
          (p) =>
            `<a href="${content.github}/${p.slug}">${pic(`card-${p.slug}`, p.title, "24%")}</a>`
        )
        .join("\n");

    const row1 = content.projects.slice(0, 4);
    const row2 = content.projects.slice(4);

    const readmeParts = [
      pic("hero", `${content.name} — ${content.role}`, "100%"),
      `<br>\n<a href="${content.github}">${pic("btn-github", "GitHub")}</a>&nbsp;\n<a href="${content.linkedin}">${pic("btn-linkedin", "LinkedIn")}</a>&nbsp;\n<a href="${content.portfolio}">${pic("btn-portfolio", "Portfolio")}</a>`,
      pic("about", "About and journey", "100%"),
      pic("skills", "Technologies and skills", "100%"),
      pic("projects-title", "Selected projects", "100%"),
      cardPics(row1),
      row2.length ? cardPics(row2) : "",
      pic("footer", "Build, Explore, Understand", "100%"),
      `<sub><a href="${content.portfolio}">portfolio</a> &nbsp;·&nbsp; <a href="${content.linkedin}">LinkedIn</a></sub>`,
    ].filter(Boolean);

    const readme = `<div align="center">\n\n${readmeParts.join("\n\n")}\n\n</div>\n`;

    let bytes = 0;
    Object.values(files).forEach((str) => (bytes += new Blob([str]).size));

    return { files, readme, meta: { bytes } };
  },
};
