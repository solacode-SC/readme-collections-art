import { Content, RenderCtx, RenderResult, StyleModule } from "../../types";
import { escapeXml, f1, pic } from "../../lib/svg";

const MONO = "'JetBrains Mono','SF Mono',SFMono-Regular,Consolas,Menlo,monospace";
const SERIF = "Georgia,'Iowan Old Style','Palatino Linotype','Book Antiqua','DejaVu Serif',serif";

interface ThemeColors {
  bg1: string;
  bg2: string;
  fg: string;
  ink: string;
  mute: string;
  blue: string;
  blue2: string;
  verm: string;
  gold: string;
  line: string;
  card: string;
  cream: string;
  teal: string;
  orange: string;
}

const THEMES: Record<"dark" | "light", ThemeColors> = {
  light: {
    bg1: "#f7edcc",
    bg2: "#e9d6a2",
    fg: "#2a2118",
    ink: "#2a1d12",
    mute: "#6b5a43",
    blue: "#1d3f94",
    blue2: "#2f5fc4",
    verm: "#c4321f",
    gold: "#b3841c",
    line: "#c7ad70",
    card: "#fbf3d8",
    cream: "#fbf1d0",
    teal: "#2b8484",
    orange: "#e8892a",
  },
  dark: {
    bg1: "#0f1c47",
    bg2: "#070d26",
    fg: "#f4e9c9",
    ink: "#080c1e",
    mute: "#b9ac8a",
    blue: "#1a3270",
    blue2: "#4a74e0",
    verm: "#e5583e",
    gold: "#e8c45a",
    line: "#4a5a98",
    card: "#12224f",
    cream: "#f4e9c9",
    teal: "#4cb0aa",
    orange: "#ff9a45",
  },
};

const STYLE = `<style>
.spin{transform-box:fill-box;transform-origin:center;animation:spin 80s linear infinite}
.spin.r{animation-direction:reverse}
@keyframes spin{to{transform:rotate(360deg)}}
.tw{transform-box:fill-box;transform-origin:center;animation:tw 4s ease-in-out infinite}
@keyframes tw{0%,100%{opacity:.3;transform:scale(.6)}50%{opacity:1;transform:scale(1.15)}}
.flick{animation:fl 2.8s ease-in-out infinite}
@keyframes fl{0%,100%{opacity:.65}30%{opacity:1}55%{opacity:.5}80%{opacity:.95}}
.glow{animation:glow 6s ease-in-out infinite}
@keyframes glow{0%,100%{opacity:.35}50%{opacity:.95}}
@media (prefers-reduced-motion:reduce){.spin,.tw,.flick,.glow{animation:none}}
</style>`;

function defs(c: ThemeColors): string {
  return `<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c.bg1}"/><stop offset="1" stop-color="${c.bg2}"/></linearGradient>
<linearGradient id="gold" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c.gold}"/><stop offset="1" stop-color="${c.line}"/></linearGradient>
</defs>`;
}

function wrap(w: number, h: number, c: ThemeColors, body: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" font-family="${SERIF}">
${STYLE}${defs(c)}<rect width="${w}" height="${h}" fill="url(#bg)"/>${body}
<path d="M.5 0V${h}M${w - 0.5} 0V${h}" stroke="${c.line}" stroke-width="1.2"/></svg>`;
}

function quatrefoil(x: number, y: number, s: number, c: ThemeColors): string {
  let o = "";
  const offsets: [number, number][] = [[1, 0], [-1, 0], [0, 1], [0, -1]];
  offsets.forEach(([dx, dy]) => {
    o += `<circle cx="${f1(x + dx * s)}" cy="${f1(y + dy * s)}" r="${f1(s * 0.62)}" fill="url(#gold)" stroke="${c.ink}" stroke-width=".6"/>`;
  });
  return o + `<circle cx="${f1(x)}" cy="${f1(y)}" r="${f1(s * 0.55)}" fill="${c.verm}" stroke="${c.ink}" stroke-width=".6"/>`;
}

function border(w: number, h: number, c: ThemeColors): string {
  return `<rect x="12" y="12" width="${w - 24}" height="${h - 24}" fill="none" stroke="${c.gold}" stroke-width="1.8"/>
<rect x="16" y="16" width="${w - 32}" height="${h - 32}" fill="none" stroke="${c.line}" stroke-dasharray="3 3"/>
${quatrefoil(12, 12, 6, c)}
${quatrefoil(w - 12, 12, 6, c)}
${quatrefoil(12, h - 12, 6, c)}
${quatrefoil(w - 12, h - 12, 6, c)}`;
}

function hero(c: ThemeColors, content: Content, heroImg: string): string {
  let b = border(900, 420, c);
  b += `<image x="480" y="32" width="370" height="356" preserveAspectRatio="xMidYMid slice" href="${heroImg}" xlink:href="${heroImg}"/>`;
  b += `<rect x="480" y="32" width="370" height="356" fill="none" stroke="${c.gold}" stroke-width="2"/>`;

  // Drop cap for first letter of name
  const init = content.name.charAt(0) || "S";
  const rest = content.name.slice(1);

  b += `<rect x="45" y="70" width="60" height="60" rx="4" fill="${c.verm}" stroke="${c.gold}" stroke-width="2"/>
<text x="75" y="116" font-size="44" font-weight="700" text-anchor="middle" fill="${c.cream}">${escapeXml(init)}</text>
<text x="115" y="112" font-size="34" font-weight="700" fill="${c.fg}">${escapeXml(rest)}</text>
<text x="45" y="160" font-size="14" font-family="${MONO}" letter-spacing="2" font-weight="700" fill="${c.gold}">${escapeXml(content.role.toUpperCase())}</text>
<text x="45" y="195" font-size="13" font-style="italic" fill="${c.mute}" xml:space="preserve">${escapeXml(content.pillars)}</text>`;

  content.tagline.forEach((t, i) => {
    b += `<text x="45" y="${235 + i * 20}" font-size="12.5" fill="${c.fg}">${escapeXml(t)}</text>`;
  });

  b += `<line x1="45" y1="310" x2="430" y2="310" stroke="${c.line}" stroke-dasharray="2 4"/>
<text x="45" y="335" font-size="11" font-family="${MONO}" fill="${c.mute}">${escapeXml(content.handle)} / CODEX ILLUMINATUS</text>`;

  return wrap(900, 420, c, b);
}

function button(c: ThemeColors, label: string): string {
  const w = 150;
  const b = `<rect x="1" y="1" width="${w - 2}" height="38" rx="4" fill="${c.card}" stroke="${c.gold}" stroke-width="1.2"/>
${quatrefoil(20, 20, 5, c)}
<text x="40" y="24" font-size="12" font-family="${MONO}" font-weight="700" fill="${c.fg}">${escapeXml(label.toUpperCase())}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} 40" width="${w}" height="40">${b}</svg>`;
}

function about(c: ThemeColors, content: Content): string {
  let b = border(900, 290, c);
  b += `<text x="50" y="52" font-size="18" font-weight="700" fill="${c.gold}">CAPITULUM I · DE VITA ET STUDIIS</text>`;

  const lines: string[] = [];
  content.about.forEach((p, idx) => {
    if (idx > 0) lines.push("");
    const words = p.split(" ");
    let cur = "";
    words.forEach((w) => {
      if ((cur + " " + w).trim().length > 44) {
        lines.push(cur.trim());
        cur = w;
      } else {
        cur = (cur + " " + w).trim();
      }
    });
    if (cur) lines.push(cur);
  });

  lines.slice(0, 8).forEach((t, i) => {
    b += `<text x="50" y="${92 + i * 21}" font-size="13" fill="${c.fg}" xml:space="preserve">${escapeXml(t)}</text>`;
  });

  b += `<line x1="460" y1="40" x2="460" y2="250" stroke="${c.line}" stroke-dasharray="2 3"/>`;
  b += `<text x="490" y="52" font-size="18" font-weight="700" fill="${c.gold}">CAPITULUM II · CURRICULUM</text>`;

  content.journey.slice(0, 5).forEach((j, i) => {
    const y = 92 + i * 30;
    b += `${quatrefoil(500, y - 4, 4, c)}
<text x="520" y="${y}" font-size="13" font-family="${MONO}" fill="${c.fg}">${escapeXml(j.lang)}</text>
<text x="640" y="${y}" font-size="13" fill="${c.gold}">⤳</text>
<text x="670" y="${y}" font-size="13" fill="${c.mute}">${escapeXml(j.area)}</text>`;
  });

  return wrap(900, 290, c, b);
}

function skills(c: ThemeColors, content: Content): string {
  let b = border(900, 250, c);
  b += `<text x="50" y="50" font-size="18" font-weight="700" fill="${c.gold}">CAPITULUM III · ARTES ET INSTRUMENTA</text>`;

  const w = 125, g = 14;
  content.skills.slice(0, 12).forEach((s, i) => {
    const x = 40 + (i % 6) * (w + g);
    const y = 72 + Math.floor(i / 6) * 72;
    b += `<rect x="${x}" y="${y}" width="${w}" height="58" rx="4" fill="${c.card}" stroke="${c.line}" stroke-width="1"/>
${quatrefoil(x + 12, y + 14, 3.5, c)}
<text x="${x + w / 2}" y="${y + 26}" font-size="15" font-family="${MONO}" font-weight="700" text-anchor="middle" fill="${c.gold}">${escapeXml(s.mono)}</text>
<text x="${x + w / 2}" y="${y + 46}" font-size="11" text-anchor="middle" fill="${c.fg}">${escapeXml(s.label)}</text>`;
  });

  return wrap(900, 250, c, b);
}

function projectsTitle(c: ThemeColors): string {
  let b = border(900, 70, c);
  b += `<text x="450" y="44" font-size="18" font-weight="700" text-anchor="middle" fill="${c.gold}">CAPITULUM IV · OPERA SELECTA</text>`;
  return wrap(900, 70, c, b);
}

function card(
  c: ThemeColors,
  idx: number,
  title: string,
  d1: string,
  d2: string,
  tags: string[],
  cardImg: string
): string {
  const w = 208, h = 184;
  const ROMAN = ["I", "II", "III", "IV", "V", "VI", "VII", "VIII"];
  let b = `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="6" fill="${c.card}" stroke="${c.gold}" stroke-width="1.2"/>
<image x="8" y="8" width="192" height="68" preserveAspectRatio="xMidYMid slice" href="${cardImg}" xlink:href="${cardImg}"/>
<rect x="8" y="8" width="192" height="68" fill="none" stroke="${c.line}" stroke-width="1"/>
<text x="14" y="24" font-size="11" font-weight="700" fill="${c.gold}">${ROMAN[idx % ROMAN.length]}</text>
<text x="14" y="98" font-size="13" font-weight="700" fill="${c.fg}">${escapeXml(title)}</text>
<text x="14" y="116" font-size="10" fill="${c.mute}">${escapeXml(d1)}</text>
<text x="14" y="129" font-size="10" fill="${c.mute}">${escapeXml(d2)}</text>`;

  let x = 14;
  tags.slice(0, 4).forEach((t) => {
    const cw = t.length * 5.1 + 8;
    b += `<rect x="${f1(x)}" y="148" width="${f1(cw)}" height="16" rx="3" fill="none" stroke="${c.line}"/>
<text x="${f1(x + cw / 2)}" y="159" font-size="8" font-family="${MONO}" text-anchor="middle" fill="${c.gold}">${escapeXml(t)}</text>`;
    x += cw + 4;
  });

  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${b}</svg>`;
}

function footer(c: ThemeColors, content: Content): string {
  let b = border(900, 140, c);
  b += `<text x="450" y="52" font-size="16" font-weight="700" letter-spacing="3" text-anchor="middle" fill="${c.gold}">${escapeXml(content.footer.line1.toUpperCase())}</text>
<text x="450" y="82" font-size="12" letter-spacing="1" text-anchor="middle" fill="${c.mute}">${escapeXml(content.footer.line2)}</text>
<text x="450" y="110" font-size="10" font-style="italic" text-anchor="middle" fill="${c.gold}">Explicit Codex · Finis coronat opus</text>`;
  return wrap(900, 140, c, b);
}

export const codexStyle: StyleModule = {
  id: "codex",
  name: "Codex",
  keywords: ["15th-century", "manuscript", "illuminated"],
  palette: {
    light: ["#f7edcc", "#2a2118", "#c4321f", "#b3841c", "#1d3f94"],
    dark: ["#0f1c47", "#f4e9c9", "#e5583e", "#e8c45a", "#4a74e0"],
  },
  motion: "calm",
  image: { file: "source.jpg", note: "Illuminated manuscript miniature" },
  async render(content: Content, ctx: RenderCtx): Promise<RenderResult> {
    const img = await ctx.loadImage("/art/codex/source.jpg");
    const heroCrop = ctx.cropToDataUrl(img, [98, 115, 298, 209], [370, 356], 0.82);

    const cropBoxes: [number, number, number, number][] = [
      [98, 115, 298, 209],
      [500, 440, 700, 534],
      [350, 200, 550, 294],
      [200, 360, 400, 454],
      [50, 670, 250, 764],
      [130, 840, 330, 934],
      [420, 560, 620, 654],
    ];

    const cardCrops = content.projects.map((_, i) =>
      ctx.cropToDataUrl(img, cropBoxes[i % cropBoxes.length], [384, 136], 0.8)
    );

    const files: Record<string, string> = {};
    for (const theme of ["dark", "light"] as const) {
      const c = THEMES[theme];
      files[`hero-${theme}.svg`] = hero(c, content, heroCrop);
      files[`about-${theme}.svg`] = about(c, content);
      files[`skills-${theme}.svg`] = skills(c, content);
      files[`projects-title-${theme}.svg`] = projectsTitle(c);
      files[`footer-${theme}.svg`] = footer(c, content);
      files[`btn-github-${theme}.svg`] = button(c, "GitHub");
      files[`btn-linkedin-${theme}.svg`] = button(c, "LinkedIn");
      files[`btn-portfolio-${theme}.svg`] = button(c, "Portfolio");

      content.projects.forEach((proj, idx) => {
        files[`card-${proj.slug}-${theme}.svg`] = card(
          c,
          idx,
          proj.title,
          proj.line1,
          proj.line2,
          proj.tags,
          cardCrops[idx]
        );
      });
    }

    const cardPics = (items: typeof content.projects) =>
      items
        .map(
          (p) =>
            `<a href="${content.github}/${p.slug}">${pic(`card-${p.slug}`, p.title, "24%")}</a>`
        )
        .join("\n");

    const row1 = content.projects.slice(0, 4);
    const row2 = content.projects.slice(4);

    const readmeParts = [
      pic("hero", `${content.name} — ${content.role}`, "100%"),
      `<br>\n<a href="${content.github}">${pic("btn-github", "GitHub")}</a>&nbsp;\n<a href="${content.linkedin}">${pic("btn-linkedin", "LinkedIn")}</a>&nbsp;\n<a href="${content.portfolio}">${pic("btn-portfolio", "Portfolio")}</a>`,
      pic("about", "About and journey", "100%"),
      pic("skills", "Technologies and skills", "100%"),
      pic("projects-title", "Selected projects", "100%"),
      cardPics(row1),
      row2.length ? cardPics(row2) : "",
      pic("footer", "Build, Explore, Understand", "100%"),
      `<sub><a href="${content.portfolio}">portfolio</a> &nbsp;·&nbsp; <a href="${content.linkedin}">LinkedIn</a></sub>`,
    ].filter(Boolean);

    const readme = `<div align="center">\n\n${readmeParts.join("\n\n")}\n\n</div>\n`;

    let bytes = 0;
    Object.values(files).forEach((str) => (bytes += new Blob([str]).size));

    return { files, readme, meta: { bytes } };
  },
};
