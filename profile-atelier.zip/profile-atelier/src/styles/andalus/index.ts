import { Content, RenderCtx, RenderResult, StyleModule } from "../../types";
import { escapeXml, f1, pic } from "../../lib/svg";

const SERIF = "Georgia,'Iowan Old Style','Palatino Linotype','DejaVu Serif',serif";
const SANS = "'Trebuchet MS','Segoe UI',Verdana,'DejaVu Sans',sans-serif";
const MONO = "'JetBrains Mono','SF Mono',SFMono-Regular,Consolas,Menlo,monospace";
const ARAB = "'Amiri','Scheherazade New','Noto Naskh Arabic','Geeza Pro','Segoe UI',Tahoma,serif";

interface ThemeColors {
  bg: string;
  bg2: string;
  panel: string;
  panel2: string;
  ink: string;
  soft: string;
  accent: string;
  gold: string;
  line: string;
  band: string;
  btn: string;
  btntxt: string;
  seal: string;
  glow: string;
  star: string;
}

const THEMES: Record<"dark" | "light", ThemeColors> = {
  dark: {
    bg: "#0D1B19",
    bg2: "#183530",
    panel: "#132826",
    panel2: "#1C3A35",
    ink: "#F3EAD3",
    soft: "#C2D2C4",
    accent: "#E8B27A",
    gold: "#CDA652",
    line: "#CDA652",
    band: "#081211",
    btn: "#B04A32",
    btntxt: "#FFF6E0",
    seal: "#C4573C",
    glow: "#A99CD0",
    star: "#F6E3A8",
  },
  light: {
    bg: "#F5ECD6",
    bg2: "#E6E4CF",
    panel: "#FBF6E6",
    panel2: "#EBE5D0",
    ink: "#17332F",
    soft: "#496660",
    accent: "#A2412A",
    gold: "#B38B34",
    line: "#B38B34",
    band: "#17332F",
    btn: "#B04A32",
    btntxt: "#FFF6E0",
    seal: "#B04A32",
    glow: "#A99CD0",
    star: "#B38B34",
  },
};

const CSS = `<style>
.a{animation-timing-function:ease-in-out;animation-iteration-count:infinite;animation-direction:alternate}
.kb{transform-box:fill-box;transform-origin:50% 45%;animation-name:kb;animation-duration:32s}
.glint{transform-box:fill-box;transform-origin:center;animation-name:glint;animation-duration:4s}
.spin{transform-box:fill-box;transform-origin:center;animation-name:spin;animation-duration:90s;animation-timing-function:linear;animation-direction:normal}
.flow{animation-name:flow;animation-duration:6s;animation-timing-function:linear;animation-direction:normal}
.breathe{animation-name:breathe;animation-duration:7s}
@keyframes kb{from{transform:scale(1)}to{transform:scale(1.06)}}
@keyframes glint{0%{opacity:.3;transform:scale(.6)}60%{opacity:1;transform:scale(1.1)}100%{opacity:.4;transform:scale(.7)}}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes flow{to{stroke-dashoffset:-48}}
@keyframes breathe{from{opacity:.55}to{opacity:1}}
@media (prefers-reduced-motion: reduce){.a{animation:none}}
</style>`;

function defs(c: ThemeColors): string {
  return `<defs>
<linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c.bg}"/><stop offset="1" stop-color="${c.bg2}"/></linearGradient>
<linearGradient id="panel" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${c.panel}"/><stop offset="1" stop-color="${c.panel2}"/></linearGradient>
<linearGradient id="gold" x1="0" y1="0" x2="1" y2="0"><stop offset="0" stop-color="${c.gold}"/><stop offset="0.5" stop-color="${c.star}"/><stop offset="1" stop-color="${c.gold}"/></linearGradient>
</defs>`;
}

function wrap(w: number, h: number, c: ThemeColors, body: string): string {
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}" font-family="${SERIF}">
${CSS}${defs(c)}<rect width="${w}" height="${h}" fill="url(#bg)"/>${body}
<path d="M.5 0V${h}M${w - 0.5} 0V${h}" stroke="${c.line}" stroke-width="1"/></svg>`;
}

function star8(cx: number, cy: number, r: number, col: string): string {
  const pts: [number, number][] = [];
  for (let i = 0; i < 16; i++) {
    const a = (i * Math.PI) / 8 - Math.PI / 2;
    const rad = i % 2 === 0 ? r : r * 0.45;
    pts.push([cx + rad * Math.cos(a), cy + rad * Math.sin(a)]);
  }
  return `<polygon points="${pts.map(([x, y]) => `${f1(x)},${f1(y)}`).join(" ")}" fill="${col}"/>`;
}

function frieze(x0: number, x1: number, y: number, c: ThemeColors): string {
  let s = `<line x1="${x0}" y1="${y}" x2="${x1}" y2="${y}" stroke="${c.line}" stroke-width="1.2"/>`;
  for (let x = x0 + 16; x < x1 - 10; x += 32) {
    s += star8(x, y, 7, c.gold);
  }
  return s;
}

function hero(c: ThemeColors, content: Content, heroImg: string): string {
  let b = `<image x="420" y="30" width="450" height="390" preserveAspectRatio="xMidYMid slice" href="${heroImg}" xlink:href="${heroImg}" class="a kb"/>`;
  b += `<rect x="420" y="30" width="450" height="390" fill="none" stroke="${c.gold}" stroke-width="2"/>`;
  b += frieze(40, 860, 24, c);

  b += `<text x="60" y="85" font-size="12" letter-spacing="3" fill="${c.gold}" font-family="${MONO}">${escapeXml(content.handle.toUpperCase())}</text>
<text x="58" y="145" font-size="44" font-family="${SERIF}" font-weight="700" fill="${c.ink}">${escapeXml(content.name)}</text>
<text x="60" y="185" font-size="14" letter-spacing="2" font-family="${SANS}" font-weight="700" fill="${c.accent}">${escapeXml(content.role.toUpperCase())}</text>`;

  if (content.options.useArabic) {
    b += `<text x="60" y="215" font-size="18" font-family="${ARAB}" fill="${c.gold}">مهندس برمجيات</text>`;
  }

  b += `<text x="60" y="250" font-size="13" font-family="${SANS}" letter-spacing="1" fill="${c.soft}">${escapeXml(content.pillars)}</text>`;

  content.tagline.forEach((t, i) => {
    b += `<text x="60" y="${285 + i * 20}" font-size="12.5" font-family="${SANS}" fill="${c.soft}">${escapeXml(t)}</text>`;
  });

  b += frieze(40, 860, 420, c);
  return wrap(900, 440, c, b);
}

function button(c: ThemeColors, label: string): string {
  const w = 150;
  const b = `<rect x="1" y="1" width="${w - 2}" height="38" rx="6" fill="${c.panel}" stroke="${c.gold}" stroke-width="1.2"/>
${star8(22, 20, 8, c.gold)}
<text x="42" y="24" font-size="12" font-family="${MONO}" font-weight="700" fill="${c.ink}">${escapeXml(label.toUpperCase())}</text>`;
  return `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} 40" width="${w}" height="40">${b}</svg>`;
}

function about(c: ThemeColors, content: Content): string {
  let b = frieze(40, 860, 20, c);
  b += `<text x="60" y="55" font-size="20" font-family="${SERIF}" font-weight="700" fill="${c.gold}">ABOUT</text>`;
  if (content.options.useArabic) {
    b += `<text x="145" y="55" font-size="16" font-family="${ARAB}" fill="${c.accent}">· نبذة عني</text>`;
  }

  const lines: string[] = [];
  content.about.forEach((p, idx) => {
    if (idx > 0) lines.push("");
    const words = p.split(" ");
    let cur = "";
    words.forEach((w) => {
      if ((cur + " " + w).trim().length > 44) {
        lines.push(cur.trim());
        cur = w;
      } else {
        cur = (cur + " " + w).trim();
      }
    });
    if (cur) lines.push(cur);
  });

  lines.slice(0, 8).forEach((t, i) => {
    b += `<text x="60" y="${95 + i * 21}" font-size="13" font-family="${SANS}" fill="${c.ink}">${escapeXml(t)}</text>`;
  });

  b += `<line x1="450" y1="40" x2="450" y2="240" stroke="${c.line}" stroke-dasharray="3 3"/>`;
  b += `<text x="490" y="55" font-size="20" font-family="${SERIF}" font-weight="700" fill="${c.gold}">JOURNEY</text>`;
  if (content.options.useArabic) {
    b += `<text x="590" y="55" font-size="16" font-family="${ARAB}" fill="${c.accent}">· رحلتي</text>`;
  }

  content.journey.slice(0, 5).forEach((j, i) => {
    const y = 95 + i * 30;
    b += `${star8(495, y - 4, 6, c.gold)}
<text x="515" y="${y}" font-size="13" font-family="${MONO}" fill="${c.ink}">${escapeXml(j.lang)}</text>
<text x="640" y="${y}" font-size="13" fill="${c.accent}">→</text>
<text x="675" y="${y}" font-size="13" font-family="${SANS}" fill="${c.soft}">${escapeXml(j.area)}</text>`;
  });

  b += frieze(40, 860, 265, c);
  return wrap(900, 280, c, b);
}

function skills(c: ThemeColors, content: Content): string {
  let b = frieze(40, 860, 20, c);
  b += `<text x="60" y="52" font-size="20" font-family="${SERIF}" font-weight="700" fill="${c.gold}">SKILLS &amp; TECHNOLOGIES</text>`;
  if (content.options.useArabic) {
    b += `<text x="320" y="52" font-size="16" font-family="${ARAB}" fill="${c.accent}">· التقنيات والمهارات</text>`;
  }

  const w = 125, g = 14;
  content.skills.slice(0, 12).forEach((s, i) => {
    const x = 40 + (i % 6) * (w + g);
    const y = 75 + Math.floor(i / 6) * 65;
    b += `<rect x="${x}" y="${y}" width="${w}" height="52" rx="4" fill="${c.panel}" stroke="${c.line}" stroke-width="1"/>
${star8(x + 12, y + 16, 5, c.gold)}
<text x="${x + w / 2}" y="${y + 24}" font-size="15" font-family="${MONO}" font-weight="700" text-anchor="middle" fill="${c.accent}">${escapeXml(s.mono)}</text>
<text x="${x + w / 2}" y="${y + 42}" font-size="10.5" font-family="${SANS}" text-anchor="middle" fill="${c.ink}">${escapeXml(s.label)}</text>`;
  });

  b += frieze(40, 860, 225, c);
  return wrap(900, 240, c, b);
}

function projectsTitle(c: ThemeColors, content: Content): string {
  let b = frieze(40, 860, 15, c);
  b += `<text x="450" y="42" font-size="20" font-family="${SERIF}" font-weight="700" text-anchor="middle" fill="${c.gold}">SELECTED PROJECTS</text>`;
  if (content.options.useArabic) {
    b += `<text x="450" y="62" font-size="15" font-family="${ARAB}" text-anchor="middle" fill="${c.accent}">مشاريع مختارة</text>`;
  }
  b += frieze(40, 860, 75, c);
  return wrap(900, 85, c, b);
}

function card(
  c: ThemeColors,
  title: string,
  d1: string,
  d2: string,
  tags: string[],
  cardImg: string
): string {
  const w = 208, h = 184;
  let b = `<rect x="1" y="1" width="${w - 2}" height="${h - 2}" rx="6" fill="${c.panel}" stroke="${c.gold}" stroke-width="1.2"/>
<image x="8" y="8" width="192" height="68" preserveAspectRatio="xMidYMid slice" href="${cardImg}" xlink:href="${cardImg}"/>
<rect x="8" y="8" width="192" height="68" fill="none" stroke="${c.line}" stroke-width="1"/>
${star8(185, 20, 6, c.gold)}
<text x="14" y="98" font-size="13" font-family="${SERIF}" font-weight="700" fill="${c.ink}">${escapeXml(title)}</text>
<text x="14" y="116" font-size="10" font-family="${SANS}" fill="${c.soft}">${escapeXml(d1)}</text>
<text x="14" y="129" font-size="10" font-family="${SANS}" fill="${c.soft}">${escapeXml(d2)}</text>`;

  let x = 14;
  tags.slice(0, 4).forEach((t) => {
    const cw = t.length * 5.1 + 8;
    b += `<rect x="${f1(x)}" y="148" width="${f1(cw)}" height="16" rx="3" fill="none" stroke="${c.line}"/>
<text x="${f1(x + cw / 2)}" y="159" font-size="8" font-family="${MONO}" text-anchor="middle" fill="${c.accent}">${escapeXml(t)}</text>`;
    x += cw + 4;
  });

  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${b}</svg>`;
}

function footer(c: ThemeColors, content: Content): string {
  let b = frieze(40, 860, 20, c);
  b += `<text x="450" y="52" font-size="16" font-family="${SERIF}" font-weight="700" letter-spacing="3" text-anchor="middle" fill="${c.gold}">${escapeXml(content.footer.line1.toUpperCase())}</text>`;
  if (content.options.useArabic && content.footer.arabic) {
    b += `<text x="450" y="78" font-size="17" font-family="${ARAB}" text-anchor="middle" fill="${c.accent}">${escapeXml(content.footer.arabic)}</text>`;
  }
  b += `<text x="450" y="104" font-size="11" font-family="${SANS}" letter-spacing="1" text-anchor="middle" fill="${c.soft}">${escapeXml(content.footer.line2)}</text>`;
  b += `<text x="450" y="126" font-size="9" font-family="${MONO}" text-anchor="middle" fill="${c.gold}" opacity=".7">NashirTech · ناشر تك</text>`;
  b += frieze(40, 860, 140, c);
  return wrap(900, 150, c, b);
}

export const andalusStyle: StyleModule = {
  id: "andalus",
  name: "Andalus",
  keywords: ["Alhambra", "zellige", "arches"],
  palette: {
    light: ["#F5ECD6", "#17332F", "#A2412A", "#B38B34", "#2A8C82"],
    dark: ["#0D1B19", "#F3EAD3", "#E8B27A", "#CDA652", "#C4573C"],
  },
  motion: "calm",
  image: { file: "source.jpg", note: "Alhambra / Moroccan zellige art" },
  options: ["useArabic"],
  async render(content: Content, ctx: RenderCtx): Promise<RenderResult> {
    const img = await ctx.loadImage("/art/andalus/source.jpg");
    const heroCrop = ctx.cropToDataUrl(img, [0, 115, 736, 1097], [500, 430], 0.82);

    const cropBoxes: [number, number, number, number][] = [
      [170, 140, 370, 340],
      [130, 410, 290, 570],
      [400, 380, 640, 620],
      [0, 780, 240, 1020],
      [440, 810, 640, 1010],
      [536, 897, 736, 1097],
      [480, 20, 730, 270],
    ];

    const cardCrops = content.projects.map((_, i) =>
      ctx.cropToDataUrl(img, cropBoxes[i % cropBoxes.length], [384, 136], 0.8)
    );

    const files: Record<string, string> = {};
    for (const theme of ["dark", "light"] as const) {
      const c = THEMES[theme];
      files[`hero-${theme}.svg`] = hero(c, content, heroCrop);
      files[`about-${theme}.svg`] = about(c, content);
      files[`skills-${theme}.svg`] = skills(c, content);
      files[`projects-title-${theme}.svg`] = projectsTitle(c, content);
      files[`footer-${theme}.svg`] = footer(c, content);
      files[`btn-github-${theme}.svg`] = button(c, "GitHub");
      files[`btn-linkedin-${theme}.svg`] = button(c, "LinkedIn");
      files[`btn-portfolio-${theme}.svg`] = button(c, "Portfolio");

      content.projects.forEach((proj, idx) => {
        files[`card-${proj.slug}-${theme}.svg`] = card(
          c,
          proj.title,
          proj.line1,
          proj.line2,
          proj.tags,
          cardCrops[idx]
        );
      });
    }

    const cardPics = (items: typeof content.projects) =>
      items
        .map(
          (p) =>
            `<a href="${content.github}/${p.slug}">${pic(`card-${p.slug}`, p.title, "24%")}</a>`
        )
        .join("\n");

    const row1 = content.projects.slice(0, 4);
    const row2 = content.projects.slice(4);

    const readmeParts = [
      pic("hero", `${content.name} — ${content.role}`, "100%"),
      `<br>\n<a href="${content.github}">${pic("btn-github", "GitHub")}</a>&nbsp;\n<a href="${content.linkedin}">${pic("btn-linkedin", "LinkedIn")}</a>&nbsp;\n<a href="${content.portfolio}">${pic("btn-portfolio", "Portfolio")}</a>`,
      pic("about", "About and journey", "100%"),
      pic("skills", "Technologies and skills", "100%"),
      pic("projects-title", "Selected projects", "100%"),
      cardPics(row1),
      row2.length ? cardPics(row2) : "",
      pic("footer", "Build, Explore, Understand", "100%"),
      `<sub><a href="${content.portfolio}">portfolio</a> &nbsp;·&nbsp; <a href="${content.linkedin}">LinkedIn</a></sub>`,
    ].filter(Boolean);

    const readme = `<div align="center">\n\n${readmeParts.join("\n\n")}\n\n</div>\n`;

    let bytes = 0;
    Object.values(files).forEach((str) => (bytes += new Blob([str]).size));

    return { files, readme, meta: { bytes } };
  },
};
