import React, { useState, useEffect } from "react";
import { Content, RenderResult, StyleModule } from "../types";
import { STYLES, getStyleById } from "../styles/registry";
import { DEFAULT_CONTENT } from "../lib/defaultContent";
import { ImageLoader } from "../lib/image";
import { ThemeMode, MotionMode, DeviceMode, saveContent } from "../state/store";
import { StyleGallery } from "../components/StyleGallery";
import { PreviewStage } from "../components/PreviewStage";
import { ContentEditor } from "../components/ContentEditor";
import { WeightGauge } from "../components/WeightGauge";
import { CatMascot } from "../components/CatMascot";
import { createStyleZip, createAllStylesZip, downloadBlob } from "../lib/zip";
import { buildAgentPrompt } from "../lib/promptBuilder";

export const App: React.FC = () => {
  const [content, setContent] = useState<Content>(() => {
    try {
      const raw = localStorage.getItem("profile_atelier_content_v1");
      if (raw) return JSON.parse(raw);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_CONTENT;
  });

  const [selectedStyleId, setSelectedStyleId] = useState<string>("swirl");
  const [theme, setTheme] = useState<ThemeMode>("dark");
  const [motion, setMotion] = useState<MotionMode>("play");
  const [device, setDevice] = useState<DeviceMode>("desktop");
  const [activeKeyword, setActiveKeyword] = useState<string | null>(null);

  const [renderResult, setRenderResult] = useState<RenderResult | null>(null);
  const [isExporting, setIsExporting] = useState<boolean>(false);
  const [exportProgress, setExportProgress] = useState<string | null>(null);

  const activeStyle = getStyleById(selectedStyleId);

  // Debounced render
  useEffect(() => {
    let cancelled = false;
    const timer = setTimeout(async () => {
      try {
        const res = await activeStyle.render(content, ImageLoader);
        if (!cancelled) {
          setRenderResult(res);
        }
      } catch (err) {
        console.error("Rendering error:", err);
      }
    }, 180);

    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [content, selectedStyleId]);

  // Persist content
  const handleContentChange = (updated: Content) => {
    setContent(updated);
    saveContent(updated);
  };

  const handleReset = () => {
    if (confirm("Reset all content to authoritative defaults?")) {
      setContent(DEFAULT_CONTENT);
      saveContent(DEFAULT_CONTENT);
    }
  };

  const handleDownloadSingle = async () => {
    if (!renderResult) return;
    setIsExporting(true);
    try {
      const blob = await createStyleZip(activeStyle, content, renderResult);
      downloadBlob(blob, `${content.handle}-${activeStyle.id}.zip`);
    } catch (err) {
      alert("Export failed: " + err);
    } finally {
      setIsExporting(false);
    }
  };

  const handleDownloadAll = async () => {
    setIsExporting(true);
    try {
      const blob = await createAllStylesZip(STYLES, content, (pct, name) => {
        setExportProgress(`${pct}% - ${name}`);
      });
      downloadBlob(blob, `${content.handle}-all-styles.zip`);
    } catch (err) {
      alert("Batch export failed: " + err);
    } finally {
      setIsExporting(false);
      setExportProgress(null);
    }
  };

  const handleCopyPrompt = () => {
    const text = buildAgentPrompt(content);
    navigator.clipboard.writeText(text);
    alert("AI Agent Prompt copied to clipboard!");
  };

  const allKeywords = Array.from(new Set(STYLES.flatMap((s) => s.keywords)));

  return (
    <div style={{ minHeight: "100vh", display: "flex", flexDirection: "column" }}>
      {/* Top Header / Spec Header */}
      <header
        style={{
          padding: "28px 40px 20px 40px",
          borderBottom: "1px solid var(--paper-200)",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: "20px",
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "baseline", gap: "14px" }}>
            <h1
              style={{
                fontSize: "36px",
                fontWeight: 300,
                letterSpacing: "0.04em",
                color: "var(--ink-900)",
                lineHeight: 1.1,
              }}
            >
              PROFILE ATELIER
            </h1>
            <span className="micro-label">SPEC STUDIO</span>
          </div>
          <p style={{ fontSize: "12px", color: "var(--ink-500)", marginTop: "6px" }}>
            Design system &amp; live README engine for GitHub profiles · Your data never leaves this page
          </p>
          <div
            style={{
              width: "28px",
              height: "2px",
              backgroundColor: "var(--ink-900)",
              marginTop: "12px",
            }}
          />
        </div>

        {/* Concept 3-line bullet */}
        <div style={{ display: "flex", flexDirection: "column", gap: "4px", fontSize: "11px", color: "var(--ink-700)" }}>
          <span className="micro-label">CONCEPT</span>
          <div>— Pick a style. See it live.</div>
          <div>— Change your info. Watch it move.</div>
          <div>— Download the zip. Push. Done.</div>
        </div>
      </header>

      {/* Main 3-Column Studio Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "280px 1fr 340px",
          flex: 1,
          minHeight: "0",
        }}
      >
        {/* Left: Style Gallery */}
        <aside
          style={{
            padding: "24px 20px",
            borderRight: "1px solid var(--paper-200)",
            overflowY: "auto",
            maxHeight: "calc(100vh - 200px)",
          }}
        >
          <StyleGallery
            styles={STYLES}
            selectedId={selectedStyleId}
            onSelect={setSelectedStyleId}
            activeKeyword={activeKeyword}
            onKeywordClick={setActiveKeyword}
          />
        </aside>

        {/* Center: Preview Stage & Controls */}
        <main
          style={{
            padding: "24px 30px",
            overflowY: "auto",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "20px",
            maxHeight: "calc(100vh - 200px)",
          }}
        >
          {/* Controls Bar */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
              maxWidth: "880px",
              flexWrap: "wrap",
              gap: "12px",
            }}
          >
            {/* Device & Theme Toggles */}
            <div style={{ display: "flex", gap: "8px" }}>
              <button
                className={`pill ${device === "desktop" ? "active" : ""}`}
                onClick={() => setDevice("desktop")}
              >
                Desktop
              </button>
              <button
                className={`pill ${device === "phone" ? "active" : ""}`}
                onClick={() => setDevice("phone")}
              >
                Phone
              </button>
              <div style={{ width: "1px", height: "26px", backgroundColor: "var(--stone-300)", margin: "0 4px" }} />
              <button
                className={`pill ${theme === "dark" ? "active" : ""}`}
                onClick={() => setTheme("dark")}
              >
                Dark
              </button>
              <button
                className={`pill ${theme === "light" ? "active" : ""}`}
                onClick={() => setTheme("light")}
              >
                Light
              </button>
            </div>

            {/* Motion Controls conforming to SYSTEM block */}
            <div style={{ display: "flex", gap: "6px", alignItems: "center" }}>
              <span className="micro-label" style={{ marginRight: "4px" }}>SYSTEM</span>
              <button
                className={`pill ${motion === "play" ? "active" : ""}`}
                onClick={() => setMotion("play")}
                title="Play animation"
              >
                走る
              </button>
              <button
                className="pill"
                onClick={() => {
                  setMotion("reduced");
                  setTimeout(() => setMotion("play"), 50);
                }}
                title="Replay animation once"
              >
                跳ぶ
              </button>
              <button
                className={`pill ${motion === "reduced" ? "active" : ""}`}
                onClick={() => setMotion("reduced")}
                title="Reduced motion"
              >
                落ちる
              </button>
            </div>
          </div>

          <PreviewStage
            content={content}
            theme={theme}
            motion={motion}
            device={device}
            result={renderResult}
          />
        </main>

        {/* Right: Content Editor */}
        <aside
          style={{
            padding: "24px 20px",
            borderLeft: "1px solid var(--paper-200)",
            overflowY: "auto",
            maxHeight: "calc(100vh - 200px)",
          }}
        >
          <ContentEditor
            content={content}
            onChange={handleContentChange}
            onReset={handleReset}
          />
        </aside>
      </div>

      {/* Bottom Spec Strip */}
      <footer
        style={{
          borderTop: "1px solid var(--paper-200)",
          backgroundColor: "var(--paper-100)",
          display: "grid",
          gridTemplateColumns: "180px 240px 300px 1fr 240px",
          padding: "16px 30px",
          alignItems: "center",
          gap: "20px",
        }}
      >
        {/* Block 1: SYSTEM */}
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <span className="micro-label">SYSTEM</span>
          <div style={{ display: "flex", gap: "4px" }}>
            <button className="pill" style={{ height: "22px", fontSize: "10px" }} onClick={() => setMotion("play")}>走る</button>
            <button className="pill" style={{ height: "22px", fontSize: "10px" }} onClick={() => setMotion("reduced")}>落ちる</button>
          </div>
        </div>

        {/* Block 2: STATE */}
        <div style={{ display: "flex", alignItems: "center", gap: "16px" }}>
          <CatMascot bytes={renderResult?.meta.bytes || 0} />
          <WeightGauge bytes={renderResult?.meta.bytes || 0} />
        </div>

        {/* Block 3: ITEMS (Exports) */}
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <span className="micro-label">ITEMS</span>
          <div style={{ display: "flex", gap: "8px" }}>
            <button
              className="btn-primary"
              style={{ height: "30px", fontSize: "11px", padding: "0 12px" }}
              onClick={handleDownloadSingle}
              disabled={isExporting}
            >
              カリカリ · Download ZIP
            </button>
            <button
              className="btn-secondary"
              style={{ height: "30px", fontSize: "11px", padding: "0 12px" }}
              onClick={handleDownloadAll}
              disabled={isExporting}
            >
              ねこ缶 · All Styles
            </button>
          </div>
          {exportProgress && (
            <span style={{ fontSize: "10px", color: "var(--ink-500)" }}>{exportProgress}</span>
          )}
        </div>

        {/* Block 4: KEYWORDS */}
        <div style={{ display: "flex", flexDirection: "column", gap: "6px", overflow: "hidden" }}>
          <span className="micro-label">KEYWORDS</span>
          <div style={{ display: "flex", gap: "4px", flexWrap: "wrap", maxHeight: "40px", overflow: "hidden" }}>
            <button
              className={`pill ${activeKeyword === null ? "active" : ""}`}
              style={{ height: "22px", fontSize: "9.5px", padding: "0 8px" }}
              onClick={() => setActiveKeyword(null)}
            >
              All
            </button>
            {allKeywords.slice(0, 8).map((kw) => (
              <button
                key={kw}
                className={`pill ${activeKeyword === kw ? "active" : ""}`}
                style={{ height: "22px", fontSize: "9.5px", padding: "0 8px" }}
                onClick={() => setActiveKeyword(activeKeyword === kw ? null : kw)}
              >
                {kw}
              </button>
            ))}
          </div>
        </div>

        {/* Block 5: COLOR PALETTE */}
        <div style={{ display: "flex", flexDirection: "column", gap: "6px" }}>
          <div style={{ display: "flex", justifyContent: "space-between" }}>
            <span className="micro-label">COLOR PALETTE</span>
            <button
              onClick={handleCopyPrompt}
              style={{ background: "none", border: "none", fontSize: "10px", textDecoration: "underline", cursor: "pointer", color: "var(--ink-700)" }}
            >
              Prompt
            </button>
          </div>
          <div style={{ display: "flex", gap: "8px" }}>
            {(theme === "dark" ? activeStyle.palette.dark : activeStyle.palette.light).map((hex, i) => (
              <div key={i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "2px" }}>
                <div
                  style={{
                    width: "20px",
                    height: "20px",
                    borderRadius: "50%",
                    backgroundColor: hex,
                    border: "1px solid var(--stone-300)",
                  }}
                />
                <span style={{ fontSize: "8px", fontFamily: "var(--font-mono)", color: "var(--ink-500)" }}>
                  {hex.slice(0, 5)}
                </span>
              </div>
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
};
